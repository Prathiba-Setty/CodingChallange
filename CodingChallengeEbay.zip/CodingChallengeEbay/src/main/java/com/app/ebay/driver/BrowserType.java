package com.app.ebay.driver;

import java.util.function.Supplier;

public enum BrowserType {
    CHROME(ChromeBrowser::new),
    EDGE(EdgeBrowser::new),
    FIREFOX(FirefoxBrowser::new);

    private Supplier<Browser> browserConsumer;

    BrowserType(Supplier<Browser> browserConsumer) {
        this.browserConsumer = browserConsumer;
    }

    public Browser init() {
        return browserConsumer.get();
    }
}
