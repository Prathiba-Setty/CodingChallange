package com.app.ebay;

import io.cucumber.core.cli.Main;

public class AutomationMain {
    public static void main(String[] args) throws Exception {
        System.out.println("Running AutomationMain...");
        System.out.println(String.join("\n", args));
        run(args);
    }

    private static void run(String[] args) {
        byte exitStatus = Main.run(args, Thread.currentThread().getContextClassLoader());
        System.exit(exitStatus);
    }
}
