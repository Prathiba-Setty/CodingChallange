package com.app.ebay.driver;

import java.util.Locale;

public class BrowserFactory {
    public static final BrowserFactory INSTANCE = new BrowserFactory();

    private final Browser browser;

    private BrowserFactory() {
        BrowserType browserType = BrowserType.valueOf(System.getProperty("browser", "chrome").toUpperCase(Locale.ROOT));
        System.out.println("BrowserType" + System.getProperty("browser","chrome"));
        browser = browserType.init();

    }

    public void init() {
        browser.init();
    }

    public Browser getBrowser() {
        return browser;
    }
}
