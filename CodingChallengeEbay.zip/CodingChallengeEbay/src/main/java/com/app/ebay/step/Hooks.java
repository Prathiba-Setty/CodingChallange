package com.app.ebay.step;

import com.app.ebay.driver.BrowserFactory;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks {
    @Before
    public static void initBrowser() {
        BrowserFactory.INSTANCE.init();
    }

    @After
    public static void teardown() {
        BrowserFactory.INSTANCE.getBrowser().close();
    }
}
