package com.app.ebay.page;

import com.app.ebay.driver.BrowserFactory;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;

public class CartPage {

    private WebDriver driver;

    @FindBy(how = How.XPATH, using = "//input[@placeholder='Search for anything']")
    private WebElement serachField;

    private String selectProduct = "//a[@aria-label='<TBD>']";

    private String selectFirstProduct = "(//span[text()='<TBD>'])[1]";

    @FindBy(how = How.XPATH, using = "//select[@aria-label='Please select a size']")
    private WebElement size;

    @FindBy(how = How.XPATH, using = "//span[text()='Add to cart']")
    private WebElement addCartXpath;

    private String cart = "//a[@aria-label='<TBD>']";

    @FindBy(how = How.XPATH, using = "//a[@title='My eBay']")
    private WebElement myEbayXpath;

    @FindBy(how = How.XPATH, using = "//button[text()='Continue']")
    private WebElement continueButtonXpath;

    private String errorMessageXpath = "//p[@id='errormsg'][contains(text(),'<TBD>')]";

    public void init() {
        driver = BrowserFactory.INSTANCE.getBrowser().getWebDriver();
        PageFactory.initElements(driver, this);
    }

    public void searchProduct(String product, String productSelection) {
        serachField.sendKeys(product);
        driver.findElement(By.xpath(selectProduct.replace("<TBD>", productSelection))).click();
    }

    public void selectFirstProduct(String firstProduct) {
        driver.findElement(By.xpath(selectFirstProduct.replace("<TBD>", firstProduct))).click();
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
    }

    public void selectSize(String productSize) {
        Select product = new Select(size);
        product.selectByVisibleText(productSize);
        addCartXpath.click();
        WebElement shadowHost = driver.findElement(By.cssSelector("#vas-interstitial-target-d"));
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        SearchContext shadowRoot = (SearchContext) jsExecutor.executeScript("return arguments[0].shadowRoot", shadowHost);
        WebElement proceedToCartButton = shadowRoot.findElement(By.cssSelector("#vas-spoke-container > div.bottom-ctas > div > button"));
        proceedToCartButton.click();
    }

    public boolean validateCart(String cartItem) {
        boolean exists = false;
        try {
            boolean presence = (driver.findElement(By.xpath(cart.replace("<TBD>", cartItem)))).isDisplayed();
            exists = true;
        } catch (Exception e) {
            exists = false;
        }
        return exists;
    }

    public void myEbay() {
        myEbayXpath.click();
        continueButtonXpath.click();
    }

    public boolean validateErrorMessage(String errorMessage) {
        boolean exists = false;
        try {
            boolean presence = (driver.findElement(By.xpath(errorMessageXpath.replace("<TBD>", errorMessage)))).isDisplayed();
            exists = true;
        } catch (Exception e) {
            exists = false;
        }
        return exists;
    }
}