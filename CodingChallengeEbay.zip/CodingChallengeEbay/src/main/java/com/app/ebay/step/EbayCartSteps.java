package com.app.ebay.step;

import com.app.ebay.driver.Browser;
import com.app.ebay.driver.BrowserFactory;
import com.app.ebay.page.CartPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

import java.util.Locale;
import java.util.ResourceBundle;

public class EbayCartSteps {

    private ResourceBundle bundle = ResourceBundle.getBundle(System.getProperty("env", "test"), Locale.ROOT);
    private final Browser browser = BrowserFactory.INSTANCE.getBrowser();
    private final CartPage cartPage;

    public EbayCartSteps(CartPage cartPage) {
        this.cartPage = cartPage;
    }

    @Given("I navigate to url")
    public void i_navigate_to_ebay_home_page() throws Exception {
        String url = bundle.getString("url");
        browser.getWebDriver().get(url);
        cartPage.init();
    }

    @When("I search for product {string} and select {string}")
    public void iSearchForProductAndSelect(String product, String productSelection) {
        cartPage.searchProduct(product, productSelection);
    }

    @And("select {string} from search result")
    public void selectFromSearchResult(String firstProduct) {
        cartPage.selectFirstProduct(firstProduct);
    }

    @And("I add product with size {string}")
    public void iAddProductWithSize(String productSize) {
        cartPage.selectSize(productSize);
    }

    @Then("I validate if cart has product {string}")
    public void iValidateIfCartHasProduct(String cartItem) {
        Assert.assertTrue(cartPage.validateCart(cartItem));
    }

    @When("I go to My ebay and continue to login without email or username")
    public void iGoToMyEbayAndContinueToLoginWithoutEmailOrUsername() {
        cartPage.myEbay();
    }

    @Then("I validate if user gets error message as {string}")
    public void iValidateIfUserGetsErrorMessageAs(String errorMessage) {
        Assert.assertTrue(cartPage.validateErrorMessage(errorMessage));
    }
}

