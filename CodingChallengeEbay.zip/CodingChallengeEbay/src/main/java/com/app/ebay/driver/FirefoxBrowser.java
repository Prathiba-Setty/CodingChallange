package com.app.ebay.driver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FirefoxBrowser extends Browser {
    @Override
    protected WebDriver initBrowser() {
        return new FirefoxDriver();
    }
}
