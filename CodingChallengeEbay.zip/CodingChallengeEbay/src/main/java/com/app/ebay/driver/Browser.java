package com.app.ebay.driver;

import org.openqa.selenium.WebDriver;

import java.time.Duration;

public abstract class Browser {

    private WebDriver webDriver;

    protected void init() {
        webDriver = initBrowser();
        postInit();
    }

    protected abstract WebDriver initBrowser();

    protected void postInit() {
        webDriver.manage().timeouts().implicitlyWait(Duration.ofMinutes(1));
        webDriver.manage().window().maximize();
    }

    public WebDriver getWebDriver() {
        return webDriver;
    }

    public void close() {
        webDriver.close();
        webDriver.quit();
    }
}
