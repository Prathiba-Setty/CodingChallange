Prerequisites:

1. Java 8 or above installed
2. Eclipse or IntelliJ IDE installed
3. Gradle Installed
4. Environment variables JAVA_HOME and GRADLE_HOME are correctly configured

Installation steps:
1. Download and Install Java on the system
2. Download and setup IDE on the system (IntelliJ preferred)
3. Install and setup Gradle
3. Install Cucumber Plugin for the IDE
4. import the project
5. Run the tests from Command Line

Command line to use:

gradle run -P tags=@Sanity -P browser=chrome -P env=test

tags - provide any tag ex: @Sanity, @Smoke, @Regression , all the scenarios having the tag will be executed.
browser - provide any of the below browser name, suite will be executed based on the browser name provided.
chrome, edge , firefox
env - provide the env, suite will be executed in the environment we provide. eg: uat, test